/**
  ******************************************************************************
  * @file    main.c
  * @author  fire
  * @version V1.0
  * @date    2013-xx-xx
  * @brief   �����жϽ��ղ���
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� F103-ָ���� STM32 ������ 
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :https://fire-stm32.taobao.com
  *
  ******************************************************************************
  */ 
 
 
#include "stm32f10x.h"
#include "bsp_usart.h"
#include "./breathinglight/bsp_breathing.h"
#include "./lcd/bsp_ili9341_lcd.h"
#include <stdio.h>
#include "bsp_TiMbase.h" 
#include "./ov7725/bsp_ov7725.h"
#include "./led/bsp_led.h"
#include "./systick/bsp_SysTick.h"
#include "./key/bsp_key.h"
#include "bsp_GeneralTim.h"  
#include "hc_sr04.h"
#include "bsp_spi_flash.h"
#include "fonts.h"

#include "EasyTracer.h"

#include "adc.h"
#include "dac.h"
#include "math.h"
#include "stdlib.h"
#include "table_fft.h"
#include "stm32_dsp.h"

uint8_t ms=0;

static void LCD_Test(void);	
extern volatile uint32_t time;// ms ��ʱ����
extern uint8_t js;// ��ʱ����
uint8_t jf=0;

extern float time2 ;
extern uint8_t Ov7725_vsync;
unsigned int Task_Delay[NumOfTask]; 
extern OV7725_MODE_PARAM cam_mode;




RESULT Resu;           
TARGET_CONDI Condition={50,80,20,250,20,200,40,40,320,240};
extern int A;




void measure();
int Trigger();
void Disp();
void fft();
void XY_F();
void XY_T();
// ADC1ת���ĵ�ѹֵͨ��DMA��ʽ����SRAM
extern __IO uint16_t ADC_ConvertedValue[NP];

long FFT_input[1024];
long FFT_output[1024];

int disp_value[240];
int T_point;
uint16_t T_value=3072;
char dispbuffer[20];
int point;
float Mag[512];

// �ֲ����������ڱ���ת�������ĵ�ѹֵ 	 
float ADC_ConvertedValueLocal;        


int cd=1,jt=1;
int main(void)
{	
	float frame_count = 0;
	uint8_t retry = 0;
	char dispBuff3[100];
	int i=0,j;
	int csh=0;
	
	/*Һ����ʼ��*/
	ILI9341_Init (); 
	
	BASIC_TIM_Init();
	TIMx_Breathing_Init();
	
  /*��ʼ��USART ����ģʽΪ 115200 8-N-1���жϽ���*/
  USART_Config();
	
	/* ��ʱ����ʼ�� */
	GENERAL_TIM_Init();
	/* �������ų�ʼ��*/
	SR04_GPIO_Config();
	/*  ������� */
	printf ( "\r\n��������������\r\n" );
	
	LCD_SetColors(RED,BLACK);

  ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* ��������ʾȫ�� */
	
//	LED_GPIO_Config();//��led��ʹ�������
	Key_GPIO_Config();
	SysTick_Init();
	
	/* ov7725 gpio ��ʼ�� */
	OV7725_GPIO_Config();
	
	ADCx_Init();						// ADC ��ʼ��
	DAC_Mode_Init();				// DAC ��ʼ��

  while(1)
	{	
		if((ms!='1')&&(ms!='2')&&(ms!='3'))
		{
		if((Key_Scan(KEY1_GPIO_PORT,KEY1_GPIO_PIN))==KEY_ON)
		{ 
			jt++;
			if(jt==5) jt=0;
		}
		switch(jt)
		{
			case 1:
				LCD_SetTextColor(BLACK);
				ILI9341_DrawRectangle( 160,64,34, 200,1);
				LCD_SetTextColor(WHITE);
				ILI9341_DrawLine( 160, 72, 192, 72 );
				ILI9341_DrawLine( 160, 72, 166, 66 );
				ILI9341_DrawLine( 160, 72, 166, 78 );
			break;
			case 2:
				LCD_SetTextColor(BLACK);
				ILI9341_DrawRectangle( 160,64,34, 200,1);
				LCD_SetTextColor(WHITE);
				ILI9341_DrawLine( 160, 120, 192, 120 );
				ILI9341_DrawLine( 160, 120, 166, 114 );
				ILI9341_DrawLine( 160, 120, 166, 126 );
			break;
			case 3:
				LCD_SetTextColor(BLACK);
				ILI9341_DrawRectangle( 160,64,34, 200,1);
				LCD_SetTextColor(WHITE);
				ILI9341_DrawLine( 160, 168, 192, 168 );
				ILI9341_DrawLine( 160, 168, 166, 162 );
				ILI9341_DrawLine( 160, 168, 166, 174 );
			break;
			case 4:
				LCD_SetTextColor(BLACK);
				ILI9341_DrawRectangle( 160,64,34, 200,1);
				LCD_SetTextColor(WHITE);
				ILI9341_DrawLine( 160, 216, 192, 216 );
				ILI9341_DrawLine( 160, 216, 166, 208 );
				ILI9341_DrawLine( 160, 216, 166, 224 );
			break;
		}
		if((Key_Scan(KEY2_GPIO_PORT,KEY2_GPIO_PIN))==KEY_ON)
		{ 
			cd++;
			if(cd>=4) cd=2;
			if((jt!=1)&&(cd==2)) cd=1; 
		}
		if((jt==4)&&(cd==3)) cd=1;
		if((jt==1)&&(cd==3)) ms='1';
		if((jt==2)&&(cd==3)) ms='2';
		if((jt==3)&&(cd==3))
		{ 
			/* ov7725 �Ĵ���Ĭ�����ó�ʼ�� */
	while(OV7725_Init() != SUCCESS)
	{
		retry++;
		if(retry>5)
		{
			printf("\r\nû�м�⵽OV7725����ͷ\r\n");
			ILI9341_DispStringLine_EN(LINE(2),"No OV7725 module detected!");
			while(1);
		}
	}
			ms='3';
			/*��������ͷ����������ģʽ*/
	OV7725_Special_Effect(cam_mode.effect);
	/*����ģʽ*/
	OV7725_Light_Mode(cam_mode.light_mode);
	/*���Ͷ�*/
	OV7725_Color_Saturation(cam_mode.saturation);
	/*���ն�*/
	OV7725_Brightness(cam_mode.brightness);
	/*�Աȶ�*/
	OV7725_Contrast(cam_mode.contrast);
	/*����Ч��*/
	OV7725_Special_Effect(cam_mode.effect);
	
	/*����ͼ�������ģʽ��С*/
	OV7725_Window_Set(cam_mode.cam_sx,
														cam_mode.cam_sy,
														cam_mode.cam_width,
														cam_mode.cam_height,
														cam_mode.QVGA_VGA);

	/* ����Һ��ɨ��ģʽ */
	ILI9341_GramScan( cam_mode.lcd_scan );
	printf("\r\nOV7725����ͷ�ٴγ�ʼ�����\r\n");
	
	Ov7725_vsync = 0;
		}
		LCD_Test();
		}
		else
		{
			ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* ��������ʾȫ�� */
		while(ms=='1')
		{ 
			ILI9341_GramScan ( 6 );
			LCD_Test();
			if((Key_Scan(KEY2_GPIO_PORT,KEY2_GPIO_PIN))==KEY_ON)
			{ 
				cd++;
				if(cd==4) cd=2;
				ms='0';
				ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* ��������ʾȫ�� */
			}
		}
		
		while(ms=='2')
		{
			
			HC_SR04();		// ����������
		/*������ж�*/
		if(TIM_ICUserValueStructure.Capture_FinishFlag == 1)
		{
								// ����ߵ�ƽʱ��ļ�������ֵ
			time2 = TIM_ICUserValueStructure.Capture_Period * 1000 + 
			       (TIM_ICUserValueStructure.Capture_CcrValue+1);   //�������nsʱ��
			
//			LCD_Test();	 //��ʾ����ʾ
//			delay_us(3);			//����ʱ
			
			
			printf ("\r\n���볤�ȣ�%f",time2/58.0);		// �������
			
			Trigger();
			Disp();
			if(i==50||i==0)
			{
				LCD_SetTextColor(BLACK);
				for(j=0 ; j<513 ; j++)
				{
					if(j!=0)
					ILI9341_DrawLine(20+j*0.4,160+Mag[j-1],20+(1+j)*0.4,160+Mag[j]);
				}
				measure();
				fft();
				XY_F();
				i=0;
			}
			i++;
			
			TIM_ICUserValueStructure.Capture_FinishFlag = 0;	//���������־����
			
		}
		if((Key_Scan(KEY2_GPIO_PORT,KEY2_GPIO_PIN))==KEY_ON)
			{ 
				cd++;
				if(cd>=4) cd=2;
				jt=1;
				ms='0';
				ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* ��������ʾȫ�� */
				ILI9341_GramScan ( 6 );
			}
		}
		

		while(ms=='3')
		{
		/*���յ���ͼ�������ʾ*/
		if( Ov7725_vsync == 2 )
		{
			frame_count++;
			FIFO_PREPARE;  			/*FIFO׼��*/					
			ImagDisp(cam_mode.lcd_sx,
								cam_mode.lcd_sy,
								cam_mode.cam_width,
								cam_mode.cam_height);			/*�ɼ�����ʾ*/
			
			Ov7725_vsync = 0;	
			if(Trace(&Condition,&Resu))
				{			
					ILI9341_DrawRectangle ( Resu.x-Resu.w/2, Resu.y-Resu.h/2, Resu.w, Resu.h, 0 );//��ס��ʶ������
					ILI9341_DrawRectangle ( Resu.x-2, Resu.y-2, 4, 4,  1 );//����׼��
					A=Resu.w;
					sprintf(dispBuff3,"%d*%d",Resu.w, Resu.h);
					ILI9341_DispString_EN ( Resu.x-Resu.w/2, Resu.y-Resu.h/2, dispBuff3 );//��ʾ�����С����ӱ�ʾ�������
					
				}	
//			LED1_TOGGLE;

		}
		
//		/*��ⰴ��*/
//		if( Key_Scan(KEY1_GPIO_PORT,KEY1_GPIO_PIN) == KEY_ON  )
//		{
////			/*LED��ת*/
////			LED2_TOGGLE;

//		} 
//		/*��ⰴ��*/
//		if( Key_Scan(KEY2_GPIO_PORT,KEY2_GPIO_PIN) == KEY_ON  )
//		{
//			/*LED��ת*/
////			LED3_TOGGLE;			
//			
//				/*��̬��������ͷ��ģʽ��
//			    ����Ҫ��������ʹ�ô��ڡ��û���������ѡ���ȷ�ʽ�޸���Щ������
//			    �ﵽ��������ʱ��������ͷģʽ��Ŀ��*/
//			
//				cam_mode.QVGA_VGA = 0,	//QVGAģʽ
//				cam_mode.cam_sx = 0,
//				cam_mode.cam_sy = 0,	

//				cam_mode.cam_width = 320,
//				cam_mode.cam_height = 240,

//				cam_mode.lcd_sx = 0,
//				cam_mode.lcd_sy = 0,
//				cam_mode.lcd_scan = 3, //LCDɨ��ģʽ�����������ÿ���1��3��5��7ģʽ

//				//���¿ɸ����Լ�����Ҫ������������Χ���ṹ�����Ͷ���	
//				cam_mode.light_mode = 0,//�Զ�����ģʽ
//				cam_mode.saturation = 0,	
//				cam_mode.brightness = 0,
//				cam_mode.contrast = 0,
//				cam_mode.effect = 1,		//�ڰ�ģʽ
//			
//			/*��������ͷ����д������*/
//			OV7725_Special_Effect(cam_mode.effect);
//			/*����ģʽ*/
//			OV7725_Light_Mode(cam_mode.light_mode);
//			/*���Ͷ�*/
//			OV7725_Color_Saturation(cam_mode.saturation);
//			/*���ն�*/
//			OV7725_Brightness(cam_mode.brightness);
//			/*�Աȶ�*/
//			OV7725_Contrast(cam_mode.contrast);
//			/*����Ч��*/
//			OV7725_Special_Effect(cam_mode.effect);
//			
//			/*����ͼ�������ģʽ��С*/
//			OV7725_Window_Set(cam_mode.cam_sx,
//																cam_mode.cam_sy,
//																cam_mode.cam_width,
//																cam_mode.cam_height,
//																cam_mode.QVGA_VGA);

//			/* ����Һ��ɨ��ģʽ */
//			ILI9341_GramScan( cam_mode.lcd_scan );
//		}
		
		/*ÿ��һ��ʱ�����һ��֡��*/
		if(Task_Delay[0] == 0)  
		{			
			printf("\r\nframe_ate = %.2f fps\r\n",frame_count/10);
			frame_count = 0;
			Task_Delay[0] = 10000;
		}
		if((Key_Scan(KEY2_GPIO_PORT,KEY2_GPIO_PIN))==KEY_ON)
		{ 
				cd++;
				if(cd>=4) cd=2;
				jt=1;
				ms='0';
				ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* ��������ʾȫ�� */
				ILI9341_GramScan ( 6 );
		}
	}

	}
	}
}	


void LCD_Test(void)
{	
	char dispBuff[100];
	char dispBuff2[100];
	
	LCD_SetFont(&Font8x16);
	LCD_SetTextColor(WHITE);
	
	if(ms=='1')
	{
		if(js%5!=0) jf=(js/5)*5+5;
		else jf=js;
	
	
		/*ʹ��c��׼��ѱ���ת�����ַ���*/
		sprintf(dispBuff,"Time : %d      ",js);
		sprintf(dispBuff2,"Money : %d     ",jf);
	
		/*Ȼ����ʾ���ַ������ɣ���������Ҳ����������*/
		ILI9341_DispStringLine_EN(LINE(0),"MS:1          ");
//	if(ms=='2') ILI9341_DispStringLine_EN(LINE(0),"MS:2          ");
		
		ILI9341_DispStringLine_EN(LINE(1),dispBuff);
		ILI9341_DispStringLine_EN(LINE(2),dispBuff2);
	}
	else switch(cd)
	{
		case 1:
			//һ���˵�
			ILI9341_DispStringLine_EN(LINE(0),"  Timing and billing device");
			ILI9341_DispStringLine_EN(LINE(4),"MENU          ");
			ILI9341_DispStringLine_EN(LINE(7),"SET           ");
			ILI9341_DispStringLine_EN(LINE(10),"POWER         ");
			ILI9341_DispStringLine_EN(LINE(13),"EXIT        ");
			break;
		default:
			if(jt==1)
			{
			//�����˵�
			ILI9341_DispStringLine_EN(LINE(0),"MENU                        ");
			ILI9341_DispStringLine_EN(LINE(4),"FUNCTION 1     ");
			ILI9341_DispStringLine_EN(LINE(7),"FUNCTION 2     ");
			ILI9341_DispStringLine_EN(LINE(10),"FUNCTION 3    ");
			ILI9341_DispStringLine_EN(LINE(13),"BACK           ");
			};
			break;
	}
}






int Trigger()
{
	for(T_point=0 ; T_point<NP/5 ; T_point++)
	{
		if((ADC_ConvertedValue[T_point-1]<T_value)&&(ADC_ConvertedValue[T_point+1]>T_value))
		{
			break;
		}
	}
	return T_point;
	
}

void Disp()
{
	int i,flag=0;
	ILI9341_GramScan ( 2 );
	for(i=0 ; i<241 ; i++)
	{		
		//ADC_ConvertedValueLocal =(float) ADC_ConvertedValue[i]/4096*3.3; // ��ȡת����ADֵ	
		disp_value[i]=(ADC_ConvertedValue[i+T_point]/35);
		LCD_SetTextColor(RED);
		//ILI9341_SetPointPixel(i,disp_value[i]);
		if(i!=0)
		ILI9341_DrawLine(i-1,disp_value[i-1],i,disp_value[i]);
		if(i==240)
		{
				LCD_SetTextColor(BLACK);
//			flag++;
//			if(flag==1)
//			{
//			for(i=0 ; i<241 ; i++)
//			ILI9341_SetPointPixel(i,disp_value[i]);
//			flag=0;
//			}

			for(i=0 ; i<240 ; i++)
			{
				if(i!=0)
				ILI9341_DrawLine(i-1,disp_value[i-1],i,disp_value[i]);
			}
			
			XY_T();
			DMA_Cmd(ADC_DMA_CHANNEL , DISABLE);
			DMA_SetCurrDataCounter(ADC_DMA_CHANNEL,NP);
			DMA_Cmd(ADC_DMA_CHANNEL , ENABLE);	
		}
	}
}




void measure()
{
	uint16_t max,min,i;
	float dispvalue_max,dispvalue_min,F,A=3.3,B=4096,fs=176.471;
	int min_n,max_n,F_n;
	ILI9341_GramScan ( 6 );
//point=0;
//flag=0;
	for(i=NP/10 ; i<NP/5 ; i++)
	{
		if(i==NP/10)
		{
			max_n=0;
			min_n=0;
			max=ADC_ConvertedValue[i];
			min=ADC_ConvertedValue[i];
		}
		if(max<ADC_ConvertedValue[i])
		{
			max=ADC_ConvertedValue[i];
			max_n=i;
		}
		if(min>ADC_ConvertedValue[i])
		{
			min=ADC_ConvertedValue[i];
			min_n=i;
//			flag++;
		}
//		if(flag%2==0)
//		point=point+abs(min_n-max_n);
	}
	
		//��ʾ
	
		dispvalue_max =(float) ADC_ConvertedValue[max_n]/B*A;
		dispvalue_min =(float) ADC_ConvertedValue[min_n]/B*A;
//		point=point/flag;
		//dispvalue_F=fs/(point-1);
		//sprintf(dispbuffer,"Vmax:%f	 Vmin:%f	Fre:%f K",dispvalue_max,dispvalue_min,dispvalue_F);
		LCD_SetFont(&Font8x16);
		LCD_SetTextColor(GREEN);
	  sprintf(dispbuffer,"Vmax:%f",dispvalue_max);
		ILI9341_DispStringLine_EN(LINE(0),dispbuffer);
		sprintf(dispbuffer,"Vmin:%f",dispvalue_min);
		ILI9341_DispStringLine_EN(LINE(1),dispbuffer);
		sprintf(dispbuffer,"Vave:%f",(dispvalue_min+dispvalue_max)/2);
		ILI9341_DispStringLine_EN(LINE(2),dispbuffer);
//		sprintf(dispbuffer,"Fre(Khz):%f ",dispvalue_F);
//		ILI9341_DispStringLine_EN(LINE(2),dispbuffer);
		
		F=Mag[1];
		F_n=0;
		for(i=1 ; i<512 ; i++)
	{
		if(F<Mag[i])
		{
			F=Mag[i];
			F_n=i;
		}
	}
		sprintf(dispbuffer,"Fre(Khz):%.3f ",(F_n)*0.175);
		ILI9341_DispStringLine_EN(LINE(3),dispbuffer);
	
	
}

void fft()
{
	
	
	
	
	int i,max_n;
	signed short lX,lY;
	float X,Y,max;
	ILI9341_GramScan ( 2 );
	for(i=0 ; i<1024 ; i++)
	{
		FFT_input[i]=ADC_ConvertedValue[i]<<16;
	}
	
	cr4_fft_1024_stm32(FFT_output,FFT_input,1024);
	max=0;
	for(i=0 ; i<513 ; i++)
	{
		lX  = (FFT_output[i] << 16) >> 16;
    lY  = (FFT_output[i] >> 16);
    X = 1024 * ((float)lX);
    Y = 1024 * ((float)lY);
    Mag[i]= sqrt(X * X + Y * Y) / 4096;
		if(Mag[i]>80)
			Mag[i]=80;
		LCD_SetTextColor(RED);
		if(i!=0)
		ILI9341_DrawLine(20+i*0.4,160+Mag[i-1],20+(1+i)*0.4,160+Mag[i]);
		
	}
}


void XY_F()
{
	int x=0,y=0;
	ILI9341_GramScan ( 2 );
	LCD_SetTextColor(BLUE);

	for(y=0 ; y<=80 ; y=y+20)
	ILI9341_DrawDottedLine_(1,160+y,240,160+y);

	for(x=0 ; x<=240 ; x=x+20)
	ILI9341_DrawDottedLine_(x+20,160,x+20,230);


	
	ILI9341_GramScan ( 6 );
	ILI9341_DispString_EN(16,160,"0Hz");
	ILI9341_DispString_EN(65,160,"26.5K");
	//ILI9341_DispString_EN(120,160,"52.5K");
	ILI9341_DispString_EN(185,160,"105K");
}


void XY_T()
{
	int x=0,y=0;
	ILI9341_GramScan ( 2 );
	LCD_SetTextColor(BLUE);
	for(y=0 ; y<=130 ; y=y+20)
	ILI9341_DrawDottedLine_(1,y,240,y);

	for(x=0 ; x<=240 ; x=x+20)
	ILI9341_DrawDottedLine_(x+20,0,x+20,100);
}
/*********************************************END OF FILE**********************/
